# SOCSTREAM: public lobby + automatic DMs

This is the next combined SOCSTREAM release. Click a participant's name, send a DM invitation, and let them accept. The C clients establish fresh encrypted DM keys automatically. There is no DM session code to exchange.

Both the browser bridge and CLI use `socstream_session.c`. The browser renders text and handles input; C owns the relay handshake, peer keys and DM encryption. The previous standalone SOCSTREAM and ZEROCOMMS releases remain separate.

## Run

Use the matching relay, client/bridge and HTML from this release together. Its wire format differs from the standalone versions.

1. Start `socstream_relay` on Linux, or `socstream_relay.exe` from the appropriate Windows folder. An optional argument sets the total connection cap, for example `socstream_relay 100`. The default is 63; the maximum is 1023. At `Starting relay port [3333]:`, press Enter for the default or choose a starting port. At `Privatize this relay? [y/N]:`, press Enter/N for OPEN, or Y for PRIVATE. The relay prints its actual listening port.
2. OPEN uses the built-in default relay identity. Clients need no relay public key and can connect with OPEN or omit the key argument. PRIVATE generates a fresh relay identity and prints its **public key**. Obtain that key through a source you trust; it changes on restart, while the corresponding private key stays in relay RAM.
3. Start `socstream_web RELAY_HOST [RELAY_PUBLIC_KEY|OPEN]` from the folder containing `socstream.html`. On Windows use `socstream_web.exe` instead. At `Relay port [3333]:`, press Enter or enter the relay's actual port. At `Starting local web port [8080]:`, press Enter or choose a starting port. Open the exact browser address printed by the bridge. The page enables chat after registration succeeds.
4. Choose a display name. Public messages go to every other connected client. Click a name to invite its temporary connection ID into a DM, or use the DM peer selector. Each invitation/conversation gets a tab. The recipient selects that tab and clicks **ACCEPT**. The shared **SEND** enables after key confirmation.

Example for a local OPEN relay, pressing Enter at each startup prompt:

```sh
./socstream_relay
./socstream_web 127.0.0.1
```

For PRIVATE, append the relay's actual 64 hexadecimal public-key digits instead. The CLI uses `socstream_client RELAY_HOST [RELAY_PUBLIC_KEY|OPEN]` with the same key selection and `Relay port [3333]:` prompt. Commands: `/display NAME`, `/display` to clear it, `/peers`, `/dm ID`, `/accept ID`, `/close ID`, `/lobby`, `/exit`. Selecting a DM keeps messages private while it is waiting or closed; sending is rejected until that DM is ready. `/lobby` explicitly returns to public sending.

Starting ports accept 1–65535. Relays and local web bridges try upward from their starting port, skipping ports that are busy or permission-restricted, and stop at 65535 without wrapping. Multiple copies of the same executable can therefore use separate available ports. Clients connect only to the relay port you choose; they do not search other lobbies. Each bridge still binds only to `127.0.0.1`, with its browser guards using that instance's actual port. Low ports can require extra permissions or already belong to another service; browsers also block some ports for HTTP, so use 8080 or another browser-compatible port for the local web bridge.

The browser uses one input, status area, CLEAR, ACCEPT and CLOSE DM for the selected tab. Switching tabs hides the other message panes with CSS, preserves their text and drafts, and marks unread conversations with an asterisk. CLEAR erases only the selected pane. A send keeps its selected recipient even if the user changes tabs while it is pending. Closing a DM, invitation expiry or peer loss destroys that conversation's pane and draft; a fresh DM starts empty. Reloading starts with empty message panes while an active C bridge can retain its live DM connections and display-name metadata. Close the bridge to end its connections and erase its own session state. Neither interface keeps a saved transcript.

## Trust and storage

- PRIVATE pins the supplied relay public key through `Noise_NK_25519_ChaChaPoly_SHA256`. A wrong key or altered handshake fails; there is no automatic OPEN fallback. OPEN deliberately skips verifying the operator's identity by using a built-in key pair whose private key is public knowledge. Both modes retain the encrypted handshake and transport checks; anyone can impersonate an OPEN relay.
- Each connection advertises a fresh temporary DM public key through the encrypted relay channel. Each DM uses another NK handshake, independent keys in each direction, and encrypted confirmation before application messages are accepted.
- The relay routes DM ciphertext only to the addressed participant. Public messages are visible to the lobby and relay. Display names are freely chosen labels; the relay supplies the actual temporary connection ID and never keeps a display-name directory. Clients announce name changes separately from chat and send their current label to newcomers; each client keeps bounded live name metadata in RAM. The bridge repeats that metadata in bounded batches so a page reload or discarded event does not depend on another chat message to restore labels.
- **The relay operator is trusted to introduce peer keys correctly.** A malicious genuine relay can substitute those introductions and intercept DMs. This version does not independently authenticate a real-world person. The unchanged standalone ZEROCOMMS remains available for its existing privately exchanged code workflow.
- This is newly implemented cryptographic/protocol code with tests, and needs independent review before reliance for sensitive communications. Tests are not a security audit.
- No accounts, history files, offline queue, database, payload logs, cookies or web storage. Keys and bounded queues are held in process memory. Browsers retain displayed text in RAM. OS paging, crash dumps, browser internals and compromised endpoints are outside that persistence guarantee; IP routing remains observable at network endpoints.

There is no separate access code, password, admission field or account. PRIVATE means the existing generated relay-key check is used; anyone who obtains that public key can connect. OPEN means no trusted relay key needs to be supplied. Clients explicitly pinning a key never abandon it because a connection fails. Closing stdin before answering a startup question aborts startup.

## Build

Linux: `sh build_socstream.sh` with a C compiler. `CC` and `CFLAGS` may be set. The prebuilt Linux executables are x86-64 builds from Ubuntu 24.04; rebuild on older systems or other architectures.

Windows: `build_socstream.bat` with MinGW GCC on PATH. Prebuilt 32-bit and 64-bit executables are in `windows-x86` and `windows-x64`, each with the matching HTML. They import only Windows system DLLs: Winsock, CryptoAPI, Kernel32 and the Microsoft C runtime. They have been cross-compiled and import-checked, but not executed on Windows or verified on Windows XP.

No Node, package manager or external cryptographic library is needed to run the programs. The shared platform header selects Winsock/Windows threads or Linux sockets/pthreads. OS randomness supplies secrets; the cipher, hash, X25519 and fixed Noise NK implementation are included as C source.

## Limits and checks

Plaintext text chunks are at most 1024 bytes; a submission is at most 8192 bytes including the display name and separator. Display names are at most 63 UTF-8 bytes. Each C client has eight simultaneous DM slots and a 16 KiB outgoing queue. Relay recipients have 64 KiB outgoing queues. The browser bridge has four HTTP slots, 4 KiB header and 8 KiB body limits, a 16 KiB unread event buffer, and at most nine displayed message panes (one lobby and eight DMs), each capped at 65536 characters. Per-tab drafts are capped at 8192 characters. The bridge's fixed HTML buffer is 24 KiB; its HTTP response buffer remains 32 KiB.

The relay retains the bounded nonblocking loop: 16 KiB/s and 32 frames/s per connection, with two seconds of burst credit; 30 seconds without progress on an incomplete frame, 120 seconds total for that frame, and 60 seconds without outgoing progress. Handshake/registration gets 30 seconds. Client incomplete input/outgoing stalls get 30 seconds; invitations/key confirmation get 120 seconds. Rate limiting pauses reading rather than immediately dropping a small burst. Queue overflow disconnects the affected connection without blocking the lobby.

Both C client interfaces check relay liveness with a tiny encrypted ping every 15 seconds after the last matching reply. Only one probe is pending, with 60 seconds allowed for its matching encrypted reply. Brief stalls can recover on the existing connection. A prolonged stall closes the connection and wipes its session state; the browser clears its panes/drafts and disables SEND, while the CLI reports the ended connection and rejects further sends. Detection normally takes up to 75 seconds after the last reply; the existing incomplete-frame/output limits can close a connection sooner. Pings use the existing Noise transport and bounded queues, with no new runtime dependency. This checks relay responsiveness, not delivery of each chat message. Restarting a PRIVATE relay creates a new public key; OPEN retains its built-in default identity. Every connection still generates fresh ephemeral and transport keys. Neither mode automatically reconnects.

Dead sockets are removed, frame structures are checked before routing, and payload bytes are never interpreted as executable content. The local bridge retains loopback binding, exact Host/Origin checks, a per-run browser token, nonce CSP and one-use send permits bound to body length **and recipient**. Its JSON is escaped and the HTML uses text nodes. Code controlling the legitimate page or local process is outside that browser-request guard.

Run `sh tests/run_checks.sh` for primitive vectors, independent Noise byte comparisons, bounds checks and Linux network/bridge integration. Tests require Python with `cryptography`; this is a testing dependency only. Set `BROWSER_TESTS=1` and install Playwright/Chromium for the optional real-browser test. See `PROTOCOL.md` for the fixed wire format and `TESTING.md` for this build's validation.
