# ALTCHATS wire format v1

All connections are TCP. The default relay port is 3333 (`ALTCHATS_PORT` at build time). Startup selects a starting listening port; the relay binds the first usable port at or above it, up to 65535. Clients select the actual destination port. This does not change the wire format. All frame lengths and connection IDs use four-byte big-endian integers. A frame is `length[4] || body[length]`; partial reads and writes are tracked without assuming a TCP receive is one frame. No connection ID is reused during a relay run.

## Relay transport

PRIVATE clients pin the relay's generated 32-byte X25519 public key before connecting. OPEN clients use the built-in default identity: an X25519 private-key input of 32 zero bytes, clamped by the unchanged X25519 implementation, and its corresponding public key. This default is deliberately known to everyone, so OPEN does not verify a relay operator's identity. The CLI/bridge accept OPEN or an omitted key argument for this mode; a supplied nondefault key remains pinned and never falls back to OPEN. Both use the exact Noise name `Noise_NK_25519_ChaChaPoly_SHA256` and prologue `ALTCHATS relay v1` in ASCII. Both handshake payloads are empty. The responder's static public key is mixed as the NK pre-message.

```text
-> e, es
<- e, ee
```

Each handshake frame body is 48 bytes: a 32-byte ephemeral public key and a 16-byte encrypted-empty-payload tag. Noise Split derives separate directional transport keys. Transport bodies contain encrypted application bytes followed by a 16-byte tag, with empty associated data as specified by Noise. The nonce is four zero bytes followed by the implicit 64-bit counter in little-endian order. Counters start at zero, increment after successful encryption/decryption and never wrap; exhaustion ends the channel. Nonces are not sent as additional fields.

Encrypted frame lengths are 17–1168 bytes. The outer length is bounded framing, not an authenticated Noise field; tampered framing causes tag failure, rejection or the incomplete-frame timeout, never accepted unauthenticated plaintext. There is no compression, early application data, resumption or negotiation of cipher suites.

## Relay application packets

`type` and `name_length` are one byte. `id` is four bytes. `key` is 32 bytes. `tag` is 16 bytes. Names and text are opaque bounded byte strings; the clients normally send UTF-8. A lobby text chunk is 1–1024 bytes. A name is 0–63 bytes.

| Type | Client to relay | Relay to client |
|---|---|---|
| 1 HELLO | `type || own_temporary_DM_public_key` | — |
| 2 SELF | — | `type || assigned_id` |
| 3 JOIN | — | `type || peer_id || peer_temporary_DM_public_key` |
| 4 LEAVE | — | `type || peer_id` |
| 5 LOBBY | `type || name_length || name || text` | `type || sender_id || name_length || name || text` |
| 6 DM | `type || target_id || tag || kind || data` | `type || sender_id || tag || kind || data` |
| 7 MISSING | — | `type || missing_target_id` |
| 8 NAME | `type || target_id || name_length || name` | `type || sender_id || name_length || name` |
| 9 PING | `type || sequence[4]` | — |
| 10 PONG | — | `type || same_sequence[4]` |

HELLO is the only permitted registration packet, after a completed relay handshake. It is exactly 33 plaintext bytes (53 bytes with framing and the Noise tag): type and temporary DM public key, with no separate access-code field. Missing/extra bytes reject the connection before assigning an ID or exposing the roster. SELF confirms registration. The discarded 65-byte registration format is rejected; use matching relay and clients.

The relay supplies the sender ID, excludes the sender from public fan-out, and sends a DM envelope to exactly one target. DM kinds are 0 START (48 data bytes), 1 REPLY (48), 2 DATA (17–1105) and 3 CANCEL (zero). The relay validates these lengths without interpreting encrypted DM contents. Source IDs and JOIN/LEAVE notifications derive from current connections.

NAME uses target zero to announce a changed label to the other lobby participants, or a nonzero target to supply a label to a newcomer. An empty name clears the label. The relay checks the exact 6–69 byte packet structure, stamps the connection ID and forwards it; it keeps no name directory. Clients defer name announcements when their bounded outgoing queue is full. Names are cosmetic and never authenticate a person.

PING and PONG are exactly five plaintext bytes (25 bytes including framing and the Noise tag). Their sequence is a big-endian counter, not a secret. PING is permitted only after registration and is answered only on that same encrypted connection; it is never broadcast. Both packets use the existing directional Noise keys/counters and rate/queue limits. The shared C client sends a probe 15 seconds after its last matching PONG (initially SELF), permits only one pending probe and allows 60 seconds from initiating that probe, including any queue delay. A correctly sized stale, unsolicited or mismatched PONG does not refresh the deadline; a malformed or unauthenticated response rejects the connection. Sequence exhaustion ends the connection rather than reusing a value. Failure wipes the relay/DM keys and pending buffers. A valid PONG proves the relay processed that probe, not that it routed or delivered every chat message. Use the matching relay and clients together; older relays do not recognize PING.

## DM channel

Each C client makes a fresh RAM-only DM static key pair per relay connection. The initiating client gets the recipient's advertised public key through the encrypted relay channel (with relay identity pinned only in PRIVATE mode). A fresh 16-byte random tag distinguishes every DM attempt. Both parties derive this exact prologue:

`ASCII("ALTCHATS DM v1") || relay_public_key[32] || initiator_id[4] || responder_id[4] || tag[16]`

The prologue is 71 bytes. IDs are big-endian. DMs use the same fixed NK pattern with fresh ephemeral keys. START carries the first Noise message. The recipient holds it as an invitation; accepting produces REPLY and split keys. Both then exchange an encrypted single zero byte using DATA. Application messages are enabled only after the expected confirmation succeeds.

A subsequent DATA decrypts to `1 || name_length || name || text`. Its ciphertext and tag are inside the DM envelope, which is itself encrypted by the relay transport. Long submissions are split on UTF-8 boundaries, repeated with their display name per chunk and delivered in TCP order. No full message reassembly store is required.

DM close, peer departure, invalid inner authentication or invalid DM sequencing clears that DM's keys. Stale tags are ignored. Outer authentication failure or malformed relay-level framing closes the relay channel and wipes the client's session state. If both clients initiate simultaneously, the lower connection ID remains the initiator; the other side drops its outgoing attempt and accepts the incoming one. At most eight DM contexts exist per client. No incoming application data is displayed while an invitation is unaccepted.

## Local browser metadata

The guarded `/name` endpoint accepts a label of 0–63 UTF-8 bytes with no line breaks. `/poll` retains four-string rows. Its first row contains the client ID, current peer IDs, and live DMs as `peer:stage:tag_hex,`. State and private-message event IDs use `peer:tag_hex`; this lets the browser discard events from an ended/replaced conversation. Name rows are type 8 with a plain peer ID, label and empty text. Each response includes the own label and up to 4 KiB of rotating live peer-name rows, in addition to the bounded event inbox. These are connection metadata, not saved message history.

## Source basis

- [Noise Protocol Framework, revision 34](https://noiseprotocol.org/noise.html): NK pattern, initialization, X25519, ChaChaPoly, SHA256, HKDF and Split. This C implementation exposes the fixed NK empty-handshake-payload subset required here.
- [RFC 7748](https://www.rfc-editor.org/rfc/rfc7748.html): X25519 encoding, clamping, Montgomery ladder and test vectors.
- [RFC 8439](https://www.rfc-editor.org/rfc/rfc8439.html): the existing manual ChaCha20-Poly1305 implementation and primitive vectors.
- [Cacophony reference vectors](https://github.com/haskell-cryptography/cacophony/blob/master/vectors/cacophony.txt): independent NK transcript used to validate the Python reference before comparing the C subset. The retained vector is distributed under the accompanying Unlicense.

No protocol or cipher modifications are presented as improvements to Noise. The application framing, routing and confirmation steps above sit around the fixed specified handshake. Peer-key introductions still depend on the relay operator's honesty.
